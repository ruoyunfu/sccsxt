<template>
  <view />
</template>

<script>
import diyPage from "./diyPage/index.vue";
import pageFootWrapper from "./diyPage/common/pageFootWrapper.vue";

export default {
  components: {
    diyPage,
    pageFootWrapper
  }
}
</script>

<style scoped lang="scss">

</style>
