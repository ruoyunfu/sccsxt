export function initDeliveryTime (
	actIndex,
	actStationIndex,
	deliverySettings,
	deliveryStationList,
	deliveryTimeData
) {
	// 设置此门店的此提货点支持的配送天数
	const dayNumber = deliverySettings[actIndex].deliverySettings.selectable_days
	// 设置配送选项数据
	const timeData = {
		leftIndex: deliveryTimeData[actIndex].actDayIndex,
		rightIndex: deliveryTimeData[actIndex].actTimeIndex,
		timeText: deliveryTimeData[actIndex].deliveryTimeText
	}
	// 设置此提货点的开始与结束时间
	const startTimeStr = deliveryStationList[actIndex][actStationIndex[actIndex]].business_time_start;
	const endTimeStr = deliveryStationList[actIndex][actStationIndex[actIndex]].business_time_end;
	if (!!(startTimeStr && endTimeStr)) {
		var startTime = startTimeStr.split(':').map(item => {
			return Number(item)
		})
		var endTime = endTimeStr.split(':').map(item => {
			return Number(item)
		})
	}
	// 计算每天的日期以及星期
	const dayListData = dayList()
	// 计算时间段
	const timeListData = timeList()
	const timeStr = dayListData[0]+' '+timeListData[0]
	// 设置同城配送的时间数据
	const date = new Date();
	date.setDate(date.getDate()+timeData.leftIndex)
	const year = date.getFullYear();
	const month = (date.getMonth()+1)<10 ? '0'+(date.getMonth()+1) : (date.getMonth()+1);
	const day = date.getDate()<10 ? '0'+date.getDate() : date.getDate();
	const data = {
		date: `${year}-${month}-${day}`,
		week: dayListData[timeData.leftIndex].slice(-3, -1),
		time: timeListData[timeData.rightIndex]
	}
	return [timeStr, data]
	// 计算每天的日期以及星期
	function dayList() {
		const list = [];
		const date = new Date();
		const nowHour = date.getHours();
		const nowMinutes = date.getMinutes();
		const isClosed = (nowHour >= endTime[0] && nowMinutes >= endTime[1])
		const weeks = new Array("周日", "周一", "周二", "周三", "周四", "周五", "周六");
		for(var i=0; i<dayNumber; i++) {
			if(i == 0) {
				if (!isClosed) {
					list.push(`今天(${weeks[date.getDay()]})`)
				}
			} else if (i == 1) {
				list.push(`明天(${weeks[date.getDay()]})`)
			} else {
				list.push(`${date.getMonth()+1}月${date.getDate()}日(${weeks[date.getDay()]})`)
			}
			date.setDate(date.getDate() + 1);
		}
		return list
	}
	// 计算时间段
	function timeList() {
		const list = [];
		const date = new Date();
		const nowHour = date.getHours();
		const nowMinutes = date.getMinutes();
		const isClosed = (nowHour >= endTime[0] && nowMinutes >= endTime[1])
		if (timeData.leftIndex == 0 && nowHour >= startTime[0] && !isClosed) { // 如果选择的日期为今天且已经处于营业期间内
			for(var i=nowHour; i<endTime[0]; i++) {
				if (i == nowHour && nowMinutes == 0) { // 如果此时为整点
					list.push(`${i<10 ? '0'+i : i}:00-${i<10 ? '0'+i : i}:30`);
					list.push(`${i<10 ? '0'+i : i}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:00`);
				} else if (i == nowHour && nowMinutes <= 30) { // 如果此时在某个小时的30分钟之前0分之后
					list.push(`${i<10 ? '0'+i : i}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:00`);
				}
				if ((i+1) == endTime[0] && endTime[1] > 0 && endTime[1] < 30) { // 如果到最后一个时间段，且结束营业时间的分钟数不足在30以前
					// list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:${endTime[1]<10 ? '0'+endTime[1] : endTime[1]}`); // 最后一个时间段为整点到结束时间
				} else if (i+1 == endTime[0] && endTime[1] == 0) { // 如果整点停止营业
				} else if (i+1 == endTime[0]) { // 如果在30之后，最后时间段为整点到30，30到结束时间
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:30`);
					// list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:${endTime[1]<10 ? '0'+endTime[1] : endTime[1]}`);
				} else { // 非最后时间段
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:30`);
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:30-${(i+2)<10 ? '0'+(i+2) : i+2}:00`);
				}
			}
		} else {
			for(var i=startTime[0]; i<endTime[0]; i++) {
				if (i == startTime[0] && startTime[1] == 0) { // 开始营业时间为整点
					list.push(`${i<10 ? '0'+i : i}:00-${i<10 ? '0'+i : i}:30`);
					list.push(`${i<10 ? '0'+i : i}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:00`);
				} else if (i == startTime[0]  && startTime[1] <= 30) { // 开始营业时间的分钟数小于30
					list.push(`${i<10 ? '0'+i : i}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:00`);
				}
				if ((i+1) == endTime[0] && endTime[1] > 0 && endTime[1] < 30) { // 如果到最后一个时间段，且结束营业时间的分钟数不足在30以前
					// list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:${endTime[1]<10 ? '0'+endTime[1] : endTime[1]}`); // 最后一个时间段为整点到结束时间
				} else if (i+1 == endTime[0] && endTime[1] == 0) { // 如果整点停止营业
				} else if (i+1 == endTime[0]) { // 如果在30之后，最后时间段为整点到30，30到结束时间
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:30`);
					// list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:30-${(i+1)<10 ? '0'+(i+1) : i+1}:${endTime[1]<10 ? '0'+endTime[1] : endTime[1]}`);
				} else { // 非最后时间段
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:00-${(i+1)<10 ? '0'+(i+1) : i+1}:30`);
					list.push(`${(i+1)<10 ? '0'+(i+1) : i+1}:30-${(i+2)<10 ? '0'+(i+2) : i+2}:00`);
				}
			}
		}
		return list
	}
	// // 设置同城配送的时间数据
	// const setCityTakesTimeData = () => {
	// 	const date = new Date();
	// 	date.setDate(date.getDate()+timeData.leftIndex)
	// 	console.log(timeData.rightIndex, '索引')
	// 	const year = date.getFullYear();
	// 	const month = (date.getMonth()+1)<10 ? '0'+(date.getMonth()+1) : (date.getMonth()+1);
	// 	const day = date.getDate()<10 ? '0'+date.getDate() : date.getDate();
	// 	const data = {
	// 		date: `${year}-${month}-${day}`,
	// 		week: dayList[timeData.leftIndex].slice(-3, -1),
	// 		time: timeList[timeData.rightIndex]
	// 	}
	// 	return data
	// }
}
